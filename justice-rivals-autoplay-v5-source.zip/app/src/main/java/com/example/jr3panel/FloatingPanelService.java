package com.example.jr3panel;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingPanelService extends Service {
    private WindowManager wm; private View bubble, menu;
    private WindowManager.LayoutParams bubbleParams, menuParams;
    private boolean menuOpen = false, policeSelected = true;
    private TextView status;

    private int overlayType() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }
    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(24); d.setStroke(2, stroke); return d;
    }
    @Override public void onCreate() { super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); createBubble(); }
    private void createBubble() {
        TextView b=new TextView(this); b.setText("JR"); b.setTextColor(0xFF061109); b.setTextSize(18); b.setTypeface(Typeface.DEFAULT_BOLD); b.setGravity(Gravity.CENTER); b.setBackground(shape(0xFF35E879,0xFFFFFFFF)); bubble=b;
        bubbleParams=new WindowManager.LayoutParams(58,58,overlayType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        bubbleParams.gravity=Gravity.TOP|Gravity.START; bubbleParams.x=20; bubbleParams.y=220;
        bubble.setOnTouchListener(new View.OnTouchListener(){ float dx,dy; int sx,sy; boolean moved;
            public boolean onTouch(View v, MotionEvent e){ switch(e.getAction()){
                case MotionEvent.ACTION_DOWN: dx=e.getRawX();dy=e.getRawY();sx=bubbleParams.x;sy=bubbleParams.y;moved=false;return true;
                case MotionEvent.ACTION_MOVE: int x=(int)(e.getRawX()-dx),y=(int)(e.getRawY()-dy); if(Math.abs(x)+Math.abs(y)>10)moved=true; if(moved){bubbleParams.x=sx+x;bubbleParams.y=sy+y;wm.updateViewLayout(bubble,bubbleParams);}return true;
                case MotionEvent.ACTION_UP: if(!moved)toggleMenu();return true;
            } return false; }
        }); wm.addView(bubble,bubbleParams);
    }
    private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(0xFFFFFFFF);t.setTextSize(size);t.setPadding(8,8,8,8);return t;}
    private Button makeButton(String text, android.view.View.OnClickListener listener){Button b=new Button(this);b.setText(text);b.setOnClickListener(listener);return b;}
    private void selectTeam(boolean police){ policeSelected=police; if(status!=null) status.setText("Selected: "+(police?"POLICE":"ROBBERS")+" • Auto Play OFF"); }
    private void startMacro(){ JR3GestureService s=JR3GestureService.instance; if(s==null){Toast.makeText(this,"First enable JR3 Gesture Service in Android Accessibility settings.",Toast.LENGTH_LONG).show();return;} s.startAutoPlay(policeSelected?"POLICE":"ROBBERS"); if(status!=null)status.setText("RUNNING: "+(policeSelected?"POLICE":"ROBBERS")+" • movement only"); }
    private void stopMacro(){ JR3GestureService s=JR3GestureService.instance; if(s!=null)s.stopAutoPlay(); if(status!=null)status.setText("Auto Play OFF • stopped"); }
    private void createMenu(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(16,12,16,12);box.setBackground(shape(0xFF101B14,0xFF35E879));
        TextView title=label("JR3 AUTO PLAY • V5",18);title.setTextColor(0xFF35E879);title.setTypeface(Typeface.DEFAULT_BOLD);box.addView(title);
        box.addView(label("Single-player testing only. Basic forward movement; no game reading, aiming, shooting, or AI decisions.",12));
        box.addView(makeButton("POLICE PROFILE",v->selectTeam(true)));
        box.addView(makeButton("ROBBERS PROFILE",v->selectTeam(false)));
        box.addView(makeButton("START BASIC AUTO PLAY",v->startMacro()));
        Button stop=makeButton("STOP AUTO PLAY",v->stopMacro()); stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFFF7777));box.addView(stop);
        status=label("Selected: POLICE • Auto Play OFF",13);box.addView(status);
        box.addView(makeButton("CLOSE MENU",v->toggleMenu()));
        menu=box;menuParams=new WindowManager.LayoutParams(300,WindowManager.LayoutParams.WRAP_CONTENT,overlayType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
        menuParams.gravity=Gravity.TOP|Gravity.START;menuParams.x=90;menuParams.y=170;
    }
    private void toggleMenu(){if(!menuOpen){if(menu==null)createMenu();wm.addView(menu,menuParams);menuOpen=true;}else{if(menu!=null&&menu.getParent()!=null)wm.removeView(menu);menuOpen=false;}}
    @Override public void onDestroy(){stopMacro();if(menu!=null&&menu.getParent()!=null)wm.removeView(menu);if(bubble!=null&&bubble.getParent()!=null)wm.removeView(bubble);super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
