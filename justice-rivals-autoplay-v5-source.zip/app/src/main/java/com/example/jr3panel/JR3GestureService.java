package com.example.jr3panel;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class JR3GestureService extends AccessibilityService {
    public static volatile JR3GestureService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private boolean busy = false;
    private String team = "POLICE";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopAutoPlay(); }
    @Override public void onDestroy() {
        stopAutoPlay();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public void startAutoPlay(String selectedTeam) {
        if (Build.VERSION.SDK_INT < 24) {
            Toast.makeText(this, "Gesture automation requires Android 7 or newer.", Toast.LENGTH_LONG).show();
            return;
        }
        team = selectedTeam;
        if (running) return;
        running = true;
        busy = false;
        handler.post(loop);
        Toast.makeText(this, team + " basic movement loop started. Tap STOP to cancel.", Toast.LENGTH_SHORT).show();
    }

    public void stopAutoPlay() {
        running = false;
        busy = false;
        handler.removeCallbacks(loop);
        if (Build.VERSION.SDK_INT >= 24) try { dispatchGesture(new GestureDescription.Builder().build(), null, null); } catch (Exception ignored) { }
    }

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (!running || busy) return;
            busy = true;
            DisplayMetrics dm = getResources().getDisplayMetrics();
            float w = dm.widthPixels, h = dm.heightPixels;
            // Approximate positions from the user's landscape gameplay screenshot:
            // joystick center near (16%,77%); push upward to move forward.
            Path move = new Path();
            move.moveTo(w * 0.16f, h * 0.77f);
            move.lineTo(w * 0.16f, h * 0.68f);
            GestureDescription.StrokeDescription hold = new GestureDescription.StrokeDescription(move, 0, 450);
            GestureDescription gesture = new GestureDescription.Builder().addStroke(hold).build();
            dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription g) {
                    busy = false;
                    if (running) handler.postDelayed(loop, 600);
                }
                @Override public void onCancelled(GestureDescription g) {
                    busy = false;
                    if (running) handler.postDelayed(loop, 1000);
                }
            }, handler);
        }
    };
}
