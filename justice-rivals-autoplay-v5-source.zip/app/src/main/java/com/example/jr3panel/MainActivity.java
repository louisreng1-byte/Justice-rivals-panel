package com.example.jr3panel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 1001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        layout.setBackgroundColor(0xFF08110B);

        TextView title = new TextView(this);
        title.setText("JUSTICE RIVALS 3\\nAUTO PLAY COMPANION — V5");
        title.setTextColor(0xFF35E879); title.setTextSize(23);
        title.setPadding(0,0,0,18); layout.addView(title);

        TextView info = new TextView(this);
        info.setText("V5 provides a basic, user-started movement macro for single-player testing. It does not read the game, aim, shoot, or make AI decisions. Use only in single-player. Auto Play starts OFF; the floating STOP button cancels gestures.");
        info.setTextColor(0xFFFFFFFF); info.setTextSize(15);
        info.setPadding(0,0,0,18); layout.addView(info);

        Button accessibility = new Button(this);
        accessibility.setText("1. ENABLE JR3 GESTURE SERVICE");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(accessibility);

        Button start = new Button(this); start.setText("2. ENABLE FLOATING PANEL"); layout.addView(start);
        Button stop = new Button(this); stop.setText("CLOSE FLOATING PANEL"); layout.addView(stop);
        TextView note = new TextView(this);
        note.setText("Android will ask you to enable the JR3 gesture service in Accessibility settings. This permission allows the app to send screen gestures. Only enable it if you understand and agree.");
        note.setTextColor(0xFFB8C8BD); note.setTextSize(13); note.setPadding(0,16,0,0); layout.addView(note);

        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQUEST);
            } else startService(new Intent(this, FloatingPanelService.class));
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, FloatingPanelService.class)));
        setContentView(layout);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && Settings.canDrawOverlays(this))
            startService(new Intent(this, FloatingPanelService.class));
    }
}
