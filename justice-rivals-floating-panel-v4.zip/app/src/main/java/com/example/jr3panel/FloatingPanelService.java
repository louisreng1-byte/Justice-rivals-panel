package com.example.jr3panel;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private View bubble;
    private View menu;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams menuParams;
    private boolean menuOpen = false;

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(24);
        d.setStroke(2, stroke);
        return d;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createBubble();
    }

    private void createBubble() {
        TextView b = new TextView(this);
        b.setText("JR");
        b.setTextColor(0xFF061109);
        b.setTextSize(18);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(0xFF35E879, 0xFFFFFFFF));
        bubble = b;

        bubbleParams = new WindowManager.LayoutParams(
                58, 58, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = 20;
        bubbleParams.y = 220;

        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = bubbleParams.x; startY = bubbleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(e.getRawX() - downX);
                        int dy = (int)(e.getRawY() - downY);
                        if (Math.abs(dx) + Math.abs(dy) > 10) moved = true;
                        if (moved) {
                            bubbleParams.x = startX + dx;
                            bubbleParams.y = startY + dy;
                            wm.updateViewLayout(bubble, bubbleParams);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggleMenu();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleParams);
    }

    private TextView label(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(size);
        t.setPadding(8, 8, 8, 8);
        return t;
    }

    private void addSlider(LinearLayout box, String name) {
        TextView value = label(name + ": 50", 14);
        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(50);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF35E879));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFF35E879));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                value.setText(name + ": " + p);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        box.addView(value);
        box.addView(bar);
    }

    private void createMenu() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 14, 18, 14);
        box.setBackground(shape(0xFF101B14, 0xFF35E879));

        TextView title = label("JUSTICE RIVALS 3  •  PANEL", 17);
        title.setTextColor(0xFF35E879);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(title);

        addSlider(box, "Aim setting (demo)");
        addSlider(box, "Sensitivity (demo)");

        TextView fps = label("FPS: demo display only", 14);
        box.addView(fps);

        Button close = new Button(this);
        close.setText("CLOSE MENU");
        close.setOnClickListener(v -> toggleMenu());
        box.addView(close);

        menu = box;
        menuParams = new WindowManager.LayoutParams(
                280, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        menuParams.gravity = Gravity.TOP | Gravity.START;
        menuParams.x = 90;
        menuParams.y = 220;
    }

    private void toggleMenu() {
        if (!menuOpen) {
            if (menu == null) createMenu();
            wm.addView(menu, menuParams);
            menuOpen = true;
        } else {
            if (menu != null && menu.getParent() != null) wm.removeView(menu);
            menuOpen = false;
        }
    }

    @Override
    public void onDestroy() {
        if (menu != null && menu.getParent() != null) wm.removeView(menu);
        if (bubble != null && bubble.getParent() != null) wm.removeView(bubble);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
