package com.example.jr3panel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        layout.setBackgroundColor(0xFF08110B);

        TextView title = new TextView(this);
        title.setText("JUSTICE RIVALS 3\nFLOATING COMPANION");
        title.setTextColor(0xFF35E879);
        title.setTextSize(24);
        title.setPadding(0, 0, 0, 24);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("This app displays a movable companion menu over other apps. Its sliders are visual/demo controls only; it does not change game aiming, sensitivity, or read actual game FPS.");
        info.setTextColor(0xFFFFFFFF);
        info.setTextSize(16);
        info.setPadding(0, 0, 0, 24);
        layout.addView(info);

        Button start = new Button(this);
        start.setText("Enable floating panel");
        layout.addView(start);

        Button stop = new Button(this);
        stop.setText("Close floating panel");
        layout.addView(stop);

        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    !Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, OVERLAY_REQUEST);
            } else {
                startService(new Intent(this, FloatingPanelService.class));
            }
        });

        stop.setOnClickListener(v ->
                stopService(new Intent(this, FloatingPanelService.class)));

        setContentView(layout);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, FloatingPanelService.class));
        }
    }
}
